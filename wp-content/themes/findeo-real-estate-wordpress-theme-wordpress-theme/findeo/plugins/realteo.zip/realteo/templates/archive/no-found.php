<section id="properties-not-found" class="margin-bottom-50">
	<h2><?php esc_html_e('Nothing found','realteo'); ?> </h2>
	<p><?php _e( 'We&rsquo;re sorry but we do not have any properties matching your search, try to change you search settings', 'realteo' ); ?></p>
</section>